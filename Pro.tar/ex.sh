echo " ";echo " ";echo " ";echo " ";
while [ true ]
do
echo "     ##############..... welcome to Gtech Port Scanning ..........###########"
echo "      info :"
echo "      1-to get start scanning write GO"
echo "            2-to exit of scanning you can press Ctrl+c or write EXIT"
echo "                  3-to get more Iformation About this program write INFO"
echo " " ;echo " ";echo " "
printf "Your Choise :....."
read choise
if [ $choise == 'GO' ]
then 
max=1023
con=0
TMPFILE=`mktemp /tmp/PSF.XXX` || exit 1   #temporary file that hold the result of scanning 
nmap -sV 127.0.0.1 |cut -d " " -f1 | grep "tcp"|cut -d "/" -f1  > $TMPFILE 
for i in $(cat $TMPFILE) 
do
if [ $i -gt $max ]
 then 
 echo "port [$i] is out of my Rang //my Range[[[0-1023]]]//......" # the expssion if the port number more than 1023
 fi
 if [ $i -eq 80 ]
 then
 echo $(cat 80.txt)  #file of port 80
 fi
 if [ $i -eq 21 ]
 then 
 echo $(cat 21.txt) #file of port 21
 fi
con=$(($con + 1))

done #end of for loop
 echo "totle of port is $con"
 fi
 if [ $choise == 'EXIT' ]
 then
 echo "thank you FOR used our APP"
 exit
 fi
 if [ $choise == 'INFO' ]
 then
 echo $(cat info.txt)  #Information File 
 fi
continue
done #end for while loop
