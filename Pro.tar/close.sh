netstat -tulpn |cut -d " " -f33|cut -d "/" -f1 #to get PID process ID

netstat -tulpn |cut -d ":" -f2 | cut -d "0" -f1 # to get the port

